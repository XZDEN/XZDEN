const router = require('express').Router({ mergeParams: true });
let logger = require("../logger/logger").logger;
let checker = require("../authenticate");
let admin = require("../check_admin");
const User = require("../database/User");
router.get('/', checker, admin, async (req, res) => {
    let result = await User.find();
    res.json(result);
    logger.debug((req.method, Date(), result));
});

router.get('/:id', checker, async (req, res) => {
    if (req.session.role == "admin" || req.params.id == req.session.id) {
        result = await User.findById(req.params.id);
        res.json(result)
    } else {
        res.send("Нет доступа");
    }
    logger.debug((req.method, Date(), result));
});

router.put('/:id', checker, async (req, res) => {
    if (req.params.id == req.session.id) {
        user = await User.findByIdAndUpdate(req.params.id, req.body);
        res.json(user)
    } else {
        res.send("Нет доступа");
    }
    logger.debug((req.method, Date(), result));
});

router.delete('/:id', checker, admin, async (req, res) => {
    user = await User.findByIdAndDelete(req.params.id);
    res.send("Удалено");

    logger.debug((req.method, Date(), result));
});
module.exports = router;