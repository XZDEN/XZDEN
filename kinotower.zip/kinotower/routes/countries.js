const router = require('express').Router({mergeParams: true});
var logger = require("../logger/logger").logger;
var checker = require("../authenticate");
var admin = require("../check_admin");
const Country = require('../database/Country');
router.get('/', checker, admin, async (req, res) => {
    var result = await Country.find();
    res.json(result);
    logger.debug((req.method, Date(), result));
});

module.exports = router;