const router = require('express').Router({mergeParams: true});
var logger = require("../logger/logger").logger;
var checker = require("../authenticate");
var admin = require("../check_admin");
const Category = require('../database/Category');
router.get('/', checker, admin, async (req, res) => {
    let result = await Category.find();
    res.json(result);
    logger.debug((req.method, Date(), result));
});

router.get('/:id', checker, admin, async (req, res) => {
    let result = await Category.findById(req.params.id);
    res.json(result);
    logger.debug((req.method, Date(), result));
});

router.post('/', checker, admin, async (req, res) => {
    let result = await Category.create(req.body);
    res.json(result);
    logger.debug((req.method, Date(), result));
});

router.put('/:id', checker, admin, async (req, res) => {
    let result = await Category.findByIdAndUpdate(req.params.id, req.body);
    res.json(result);
    logger.debug((req.method, Date(), result));
});

router.delete('/:id', checker, admin, async (req, res) => {
    let result = await Category.findByIdAndDelete(req.params.id);
    res.json(result)
    logger.debug((req.method, Date(), result));
});

module.exports = router;