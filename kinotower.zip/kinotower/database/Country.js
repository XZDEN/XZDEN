const mongoose = require('mongoose');

const countryModel = new mongoose.Schema({
    
    name: {
        type: String,
        required: true,
    }
});

module.exports = mongoose.model("Country", countryModel);