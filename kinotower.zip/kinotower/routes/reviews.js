let logger = require("../logger/logger").logger;
let checker = require("../authenticate");
let admin = require("../check_admin");
const Review = require('../database/Review');
module.exports = function(router) {
    router.get("/", checker, admin, async (req, res) => {
        result = await Review.find();
        res.json(result);
        logger.debug((req.method, Date(), result));
    });

    router.post("/", checker, async (req, res) => {
        req.body.user = req.session.id;
        result = await Review.create(req.body);
        res.json(result);
        logger.debug((req.method, Date(), result));
    });

    router.get("/:id", checker, async (req, res) => {
        result = await Review.findById(req.params.id);
        res.json(result);
        logger.debug((req.method, Date(), result));
    });

    router.put("/:id", checker, async (req, res) => {
        if (req.session.id == req.body.user) {
            result = await Review.findByIdAndUpdate(req.params.id, req.body);
            res.json(result);
        } else {
            res.send("Нет доступа");
        }
        logger.debug((req.method, Date(), result));
    });

    router.patch("/:id", checker, admin, async (req, res) => {
        result = Review.findOneAndUpdate(req.params.id, { isApproved: req.body.isApproved });
        res.json(result);
        logger.debug((req.method, Date(), result));
    });

    router.delete("/:id", checker, async (req, res) => {
        if (req.session.id == req.body.user) {
            result = await Review.findByIdAndDelete(req.params.id);
        } else {
            res.send("Нет доступа");
        }
        logger.debug((req.method, Date(), result));
    });
    return router;
}
